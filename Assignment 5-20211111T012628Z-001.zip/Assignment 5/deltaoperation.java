//****************************************************************************************************************************
//Program name: "Quoc's Ball bounce.".This program display a circle bouncing off of the edge of the screen                   *
//Copyright (C) 2021 Quoc Le                                                                                                 *
//This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License  *
//version 3 as published by the Free Software Foundation.                                                                    *
//This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied         *
//warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.     *
//A copy of the GNU General Public License v3 is available here:  <https://www.gnu.org/licenses/>.                           *
//****************************************************************************************************************************



//Author information:
  //Author: Quoc Le
  //Mail: quoctle00@csu.fullerton.edu

  //Program information:
    //Program name: Quoc's Bouncing Ball
    //Programming language: Java
    //Files: Ballbounce.java, ballbouncepanel.java, deltaoperation.java, maindriver.java run.sh
    //Date project began: 2021-March-3.
    //Date of last update: 2021-March-19.
    //Status: Finished; testing completed.
    //Purpose: This program will animate a circle moving in a direction bouncing off of a wall, moving circle will leave a trail of paint behind,
    //changing color rapidly as it is moving.
    //Nice feature: this program has a start and pause button, user can also change the speed of the ball moving, albeit only using
    //whole number, no decimal or invalid input such as letters or any kind of symbols.
    //Base test system: Linux system with Bash shell and openjdk-14-jdk

//This module
  //File name: deltaoperation.java
  //Compile: deltaoperation.java
  //This module is invoked from the Ballbounce class
  //Purpose: Act as the computation center of the program.
  //Educational purpose: Demonstrate how detailed operations unrelated to the definition of the UI can be and should be
  //off-loaded to a separate file, which is then invoked by the frame class.  That simply means to not clutter
  //the UI file with too many junk-filled details

//Ruler:=1=========2=========3=========4=========5=========6=========7=========8=========9=========0=========1=========2=========3**


public class deltaoperation {//There are no private internal variables
  public static int deltaX(int xcord, int xVelocity) {              //calculate delta x
    int new_deltaX = 0;
    //int deltaxInt = 0
    new_deltaX = xcord + xVelocity;
    //deltaxInt = (int)new_deltaX;
    return new_deltaX;
  }
  public static int deltaY(int ycord, int yVelocity) {
    int new_deltaY;                                                //calculate delta y
    //int deltayInt = 0;
    new_deltaY = ycord + yVelocity;
    //deltayInt = (int)new_deltaY;
    return new_deltaY;
  }

  public static double cosX(double direction, double rate_of_pix) {
    double X_delta = 0;
    if(rate_of_pix <= 0) {
      return 0;
    }
    else {
      X_delta = Math.cos(direction) * rate_of_pix;
    }
    return X_delta;
  }
  public static double sinY(double direction, double rate_of_pix) {
    double Y_delta = 0;
    if(rate_of_pix <= 0) {
      return 0;
    }
    else {
      Y_delta = Math.sin(direction) * rate_of_pix;
    }
    return Y_delta;
  }

  public static double drawSine(double x_value) {
    double value = Math.sin(x_value);
    return value;
  }

  public static double speed_tic(int tick) {                      //convert tic int to double
    double new_tick = 0;
    return new_tick;
  }

  public static double pixPerTicCalculation(double speed, double refresh) {
    double pixrate = 0;
    if(speed <= 0 || refresh <= 0) {
      return 0;
    }
    else {
      pixrate = speed/refresh;
      return pixrate;
    }
  }
}//End arithmeticoperations class
