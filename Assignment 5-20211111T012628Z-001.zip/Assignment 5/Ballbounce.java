//****************************************************************************************************************************
//Program name: "Quoc's Ball bounce.".This program display a circle bouncing off of the edge of the screen                   *
//Copyright (C) 2021 Quoc Le                                                                                                 *
//This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License  *
//version 3 as published by the Free Software Foundation.                                                                    *
//This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied         *
//warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.     *
//A copy of the GNU General Public License v3 is available here:  <https://www.gnu.org/licenses/>.                           *
//****************************************************************************************************************************



//Author information:
  //Author: Quoc Le
  //Mail: quoctle00@csu.fullerton.edu

  //Program information:
    //Program name: Quoc's Bouncing Ball
    //Programming language: Java
    //Files: Ballbounce.java, ballbouncepanel.java, deltaoperation.java, maindriver.java run.sh
    //Date project began: 2021-March-3.
    //Date of last update: 2021-March-19.
    //Status: Finished; testing completed.
    //Purpose: This program will animate a circle moving in a direction bouncing off of a wall, moving circle will leave a trail of paint behind,
    //changing color rapidly as it is moving.
    //Nice feature: this program has a start and pause button, user can also change the speed of the ball moving, albeit only using
    //whole number, no decimal or invalid input such as letters or any kind of symbols.
    //Base test system: Linux system with Bash shell and openjdk-14-jdk

//This module
  //File name: Ballbounce.java
  //Compile: Ballbounce.java
  //This module is invoked from the maindriver class
  //Purpose: Act as the main frame of the program
  //Educational purpose: Demonstrate how detailed operations unrelated to the definition of the UI can be and should be
  //off-loaded to a separate file, which is then invoked by the frame class.  That simply means to not clutter
  //the UI file with too many junk-filled details

//Ruler:=1=========2=========3=========4=========5=========6=========7=========8=========9=========0=========1=========2=========3**

import java.awt.FlowLayout;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.Dimension;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JTable;
import java.awt.Color;
import javax.swing.Timer;
import java.awt.Graphics2D;

public class Ballbounce extends JFrame {
  private JFrame frame;
  private JPanel NamePanel;
  //private JPanel DiamondPanel;
  private JPanel ButtonPanel;
  private JLabel projectnamelabel;

  private JLabel speedlabel;
  private JLabel refreshratelabel;
  private JLabel directionlabel;
  private JLabel ballLocationlabel;
  private JTextField speedtextfield;
  private JTextField refreshratefield;
  private JTextField directionfield;
  private JTextField ball_x_locationfield;
  private JTextField ball_y_locationfield;
  private String speedstring;
  private String refreshratestring;
  private String directionstring;
  private String ball_x_locationString;
  private String ball_y_locationString;
  public int speedint;
  public int refreshrateint;
  public int directionint;
  public int ball_x_locationInt;
  public int ball_y_locationInt;
  public double speeddouble;
  public double refreshratedouble;
  public double directiondouble;
  private JButton startbutton;
  private JButton exitbutton;
  private JButton clearbutton;
  public int action;
  public double pix_per_tic_double;
  public int pix_per_tic_int;
  public int intDeltaX = 0;
  public double doubleDeltaX = 0;
  public int intDeltaY = 0;
  public double doubleDeltaY = 0;
  private String clearstring;

  private bouncepanel BouncingPanel;
  Timer clock;
  Timer frameClock;
  public int clock_tick;


  public Ballbounce() {
    //Timer clock = new Timer(10,this);

    super("Bouncing ball");
    setLayout(new BorderLayout());
    setTitle("Program 3");

    projectnamelabel = new JLabel("<html>Bouncing ball<br/>By Quoc Le<html>");    //start of first panel
    NamePanel = new JPanel();
    NamePanel.setBackground(Color.magenta);   //set panel color to red
    NamePanel.setPreferredSize(new Dimension(50,50));       // (Length, height)
    NamePanel.add(projectnamelabel,BorderLayout.NORTH);
    this.add(NamePanel,BorderLayout.NORTH);


    BouncingPanel = new bouncepanel();
    //BouncingPanel.setBackground(Color.green);   //set panel color to green
    this.add(BouncingPanel,BorderLayout.CENTER);
    this.pack();


    ButtonPanel = new JPanel();
    ButtonPanel.setLayout(new GridLayout(4,3));
    ButtonPanel.setBackground(Color.magenta);
    ButtonPanel.setPreferredSize(new Dimension(100,100));
    //ButtonPanel.setLayout(new GridLayout(1,4));
    startbutton = new JButton("Start");
    startbutton.setForeground(Color.white);
    startbutton.setBackground(Color.blue);
    exitbutton = new JButton("Exit");
    exitbutton.setForeground(Color.white);
    exitbutton.setBackground(Color.red);
    clearbutton = new JButton("Clear");
    clearbutton.setBackground(Color.gray);
    clearbutton.setForeground(Color.black);
    speedlabel = new JLabel("Speed:");
    refreshratelabel = new JLabel("Refresh rate(Hz):");
    directionlabel = new JLabel("Direction:");
    speedtextfield = new JTextField(20);
    refreshratefield = new JTextField(20);
    directionfield = new JTextField(20);
    ballLocationlabel = new JLabel("Ball location (X , Y), Center coordinates is (960,465)");
    ball_x_locationfield = new JTextField(20);
    ball_y_locationfield = new JTextField(20);
    ButtonPanel.add(refreshratelabel);
    ButtonPanel.add(speedlabel);
    ButtonPanel.add(directionlabel);

    ButtonPanel.add(refreshratefield);
    ButtonPanel.add(speedtextfield);
    ButtonPanel.add(directionfield);

    ButtonPanel.add(ballLocationlabel);
    ButtonPanel.add(ball_x_locationfield);
    ButtonPanel.add(ball_y_locationfield);

    ButtonPanel.add(startbutton);
    ButtonPanel.add(exitbutton);
    ButtonPanel.add(clearbutton);
    this.add(ButtonPanel,BorderLayout.SOUTH);


    buttonhandler myhandler = new buttonhandler();
    startbutton.addActionListener(myhandler);
    exitbutton.addActionListener(myhandler);
    clearbutton.addActionListener(myhandler);

  //  clockhandler twohandler = new clockhandler();
    //arithmeticmachine = new arithmeticoperations();
    setLocationRelativeTo(null);  //This statement opens the UI in the center of the monitor.



  }//End of Constructor

  //public class clockhandler implements Actionlistener {}

  public class buttonhandler implements ActionListener {
    Timer clock = new Timer(clock_tick,BouncingPanel);
    Timer frameClock = new Timer(clock_tick,this);
    boolean labelisstart = true;
    int action = 0;
    public void actionPerformed(ActionEvent event) {


      if(event.getSource() == clearbutton) {
        clearbutton.setEnabled(true);
        action = 0;
        clearstring = " ";

        ball_x_locationString = "960";
        ball_y_locationString = "465";
        speedtextfield.setText(clearstring);
        refreshratefield.setText(clearstring);
        directionfield.setText(clearstring);
        ball_x_locationfield.setText(ball_x_locationString);
        ball_y_locationfield.setText(ball_y_locationString);
        BouncingPanel.repaint();

        System.out.print("clearbutton was pressed.\n");
      }

      else if(event.getSource() == exitbutton) {
        System.out.print("The exit button was clicked.  There are 3.5 seconds remaining.\n");
        exitbutton.setEnabled(false);
        //addbutton.setEnabled(false);
        //subtractbutton.setEnabled(false);
        System.exit(0);
      }

      else if(event.getSource() == startbutton) {
        if(labelisstart){
          speedstring = speedtextfield.getText();
          speeddouble = Double.parseDouble(speedstring);
          if(speeddouble < 0) {
            speeddouble = 1;
            System.out.print("Bad parse for speed, speed will be default to 1.\n");
            clock.stop();
            BouncingPanel.bouncepanelPause();
          }
          //speedint = (int)Math.round(speeddouble);
          refreshratestring = refreshratefield.getText();
          refreshratedouble = Double.parseDouble(refreshratestring);
          if(refreshratedouble < 0) {
            refreshratedouble = 1;
            System.out.print("Bad parse for refresh rate, refresh will be default to 1.\n");
            clock.stop();
            BouncingPanel.bouncepanelPause();
          }
          //refreshrateint = (int)Math.round(refreshratedouble);
          clock_tick = 100;
          pix_per_tic_double = deltaoperation.pixPerTicCalculation(speeddouble, refreshratedouble);
          directionstring = directionfield.getText();
          directiondouble = Double.parseDouble(directionstring);

          doubleDeltaX = deltaoperation.cosX(directiondouble, pix_per_tic_double); //
          intDeltaX = (int)Math.round(doubleDeltaX);
          doubleDeltaY = deltaoperation.sinY(directiondouble, pix_per_tic_double); //
          intDeltaY = (int)Math.round(doubleDeltaY);


          if(clock_tick <= 0) {
            clock.stop();
            BouncingPanel.bouncepanelPause();
          }
          else if(clock_tick > 0 && action == 0) {
            ball_x_locationString = ball_x_locationfield.getText();
            ball_x_locationInt = Integer.parseInt(ball_x_locationString);
            if(ball_x_locationInt < 0) {
              ball_x_locationInt = 960;
              System.out.print("X-Coordinates cannot be negative, default to 960.\n");
              clock.stop();
              BouncingPanel.bouncepanelPause();
            }
            BouncingPanel.getBallcoordX(ball_x_locationInt);
            ball_y_locationString = ball_y_locationfield.getText();
            ball_y_locationInt = Integer.parseInt(ball_y_locationString);
            if(ball_y_locationInt < 0) {
              ball_y_locationInt = 465;
              System.out.print("Y-Coordinates cannot be negative, default to 465.\n");
              clock.stop();
              BouncingPanel.bouncepanelPause();
            }

            BouncingPanel.getBallcoordY(ball_y_locationInt);
            BouncingPanel.getMyValue(clock_tick);
            BouncingPanel.getTicRate(pix_per_tic_double);
            BouncingPanel.getDirection(directiondouble);
            BouncingPanel.getDeltaX(intDeltaX);
            BouncingPanel.getDeltaY(intDeltaY);
            BouncingPanel.bouncepanelStart();
            frameClock.start();

          }

          else {
            clock.stop();
            BouncingPanel.bouncepanelPause();
            System.out.println("Invalid Input, please enter a number that contains no letters.\n");
          }
        }
        else if(clock_tick > 0 && action == 2) {
          BouncingPanel.bouncepanelStart();
          startbutton.setText("Pause");
          action = 1;
        }
        else if(action == 1){
          //clock.stop();
          BouncingPanel.bouncepanelPause();
          startbutton.setText("Start");
          action = 2;
        }
        labelisstart = !labelisstart;

      }


    }

  }
}
