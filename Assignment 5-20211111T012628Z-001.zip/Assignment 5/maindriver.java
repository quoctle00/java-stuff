//****************************************************************************************************************************
//Program name: "Quoc's Ball bounce.".This program display a circle bouncing off of the edge of the screen                   *
//Copyright (C) 2021 Quoc Le                                                                                                 *
//This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License  *
//version 3 as published by the Free Software Foundation.                                                                    *
//This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied         *
//warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.     *
//A copy of the GNU General Public License v3 is available here:  <https://www.gnu.org/licenses/>.                           *
//****************************************************************************************************************************



//Author information:
  //Author: Quoc Le
  //Mail: quoctle00@csu.fullerton.edu

  //Program information:
    //Program name: Quoc's Bouncing Ball
    //Programming language: Java
    //Files: Ballbounce.java, ballbouncepanel.java, deltaoperation.java, maindriver.java run.sh
    //Date project began: 2021-March-3.
    //Date of last update: 2021-March-19.
    //Status: Finished; testing completed.
    //Purpose: This program will animate a circle moving in a direction bouncing off of a wall, moving circle will leave a trail of paint behind,
    //changing color rapidly as it is moving.
    //Nice feature: this program has a start and pause button, user can also change the speed of the ball moving, albeit only using
    //whole number, no decimal or invalid input such as letters or any kind of symbols.
    //Base test system: Linux system with Bash shell and openjdk-14-jdk

//This module
  //File name: maindriver.java
  //Compile: maindriver.java
  //This module is invoked from the maindriver class
  //Purpose: Act as the main driver of the program
  //Educational purpose: Demonstrate how detailed operations unrelated to the definition of the UI can be and should be
  //off-loaded to a separate file, which is then invoked by the frame class.  That simply means to not clutter
  //the UI file with too many junk-filled details

//Ruler:=1=========2=========3=========4=========5=========6=========7=========8=========9=========0=========1=========2=========3**

import javax.swing.JFrame;
public class maindriver
{public static void main(String[] args)
    {
      Ballbounce myframe = new Ballbounce();
     myframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
     myframe.setSize(1920,1080);
     myframe.setVisible(true);
    }//End of main
}//End of class testarithmetic
