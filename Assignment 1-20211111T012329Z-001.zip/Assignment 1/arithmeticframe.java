//****************************************************************************************************************************
//Program name: "Assignment 1".  This program calculate an employee's simple salary while displaying the pay,overtime,       *
//and gross, while using three buttons  Copyright (C) 2021 Quoc Le                                                           *
//This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License  *
//version 3 as published by the Free Software Foundation.                                                                    *
//This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied         *
//warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.     *
//A copy of the GNU General Public License v3 is available here:  <https://www.gnu.org/licenses/>.                           *
//****************************************************************************************************************************

//Ruler:=1=========2=========3=========4=========5=========6=========7=========8=========9=========0=========1=========2=========3**

//Author information:
  //Author: Quoc Le
  //Mail: quoctle00@csu.fullerton.edu

//Program information:
  //Program name: Assignment 1
  //Programming language: Java
  //Files: testarithmetic.java, arithmeticframe.java, arithmeticoperations.java, run.sh
  //Date project began: 2021-January-25.
  //Date of last update: 2021-February-1.
  //Status: Finished; testing completed.
  //Purpose: This program demonstrate the design of a simple UI (user interface) where multiple panels are used
  //with different colors as well as the calculation of an employee's salary based on their hours worked and their payrate.
  //The program also has a built-in 3.5 seconds delay of closing the program after the Exit button has been clicked.
  //Nice feature: If no values or incorrect values are entered into the input boxes then zero is assumed to be the input,
  //as well as using the CLear button it will clear all data displayed, including the user input.
  //Base test system: Linux system with Bash shell and openjdk-14-jdk

//This module
  //File name: arithmeticframe.java
  //Compile : javac arithmeticframe.java
  //Purpose: This class defines the user interface
  //This module (class) is called from the testarithmetic class.
  //Educational purpose of this arithmeticframe class:
    //   1.  Demonstrate the common technique of partitioning a software solution into 3 or more source files.
    //   2.  Demonstrate the use of multiple colors in the UI (user interface) as well as manipulations of panels
    //   3.  Demonstrate how to delay the action of a button-click; in this case, the action of the Exit button is delayed.
    //   4.  Demonstrate how to implement a conditional event where a different fucntion will be execute when a double values
    //        exceeds a certain amount.

import java.awt.FlowLayout;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.Dimension;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JTable;
import java.awt.Color;
import javax.swing.Timer;

public class arithmeticframe extends JFrame
{
  private final int length_of_delay = 3500;  //Time is measured in milliseconds

 private JFrame frame;
 private JPanel InfoPanel;                  //1st panel
 private JPanel EmployeePanel;              //2nd panel
 private JPanel DisplayEmployeePanel;       //3rd panel
 private JPanel ButtonLayoutPanel;          //4th panel

 private JLabel companynamelabel;
 private JLabel payrolsystemnamelabel;

 private JButton exitbutton;
 private JButton computebutton;
 private JButton clearbutton;

 private JLabel employeenamelabel;
 private JLabel hoursworkedlabel;
 private JLabel payratelabel;
 private JTextField employeenametextfield;
 private JTextField hoursworkedtextfield;
 private JTextField payratetextfield;

 private JLabel displayemployeenamelabel;
 private JLabel displayregularpaylabel;
 private JLabel displayovertimepaylabel;
 private JLabel displaygrosspaylabel;
 private JTextField displayemployeenametextfield;
 private JTextField displayregularpaytextfield;
 private JTextField displayovertimepaytextfield;
 private JTextField displaygrosspaytextfield;

 private String employeenamestring;
 private String hoursworkedstring;
 private String payratestring;

 private double hoursworkeddouble;
 private double regularhoursworkeddouble;
 private double payratedouble;

 private String regularpaystring;
 private String overtimepaystring;
 private String grosspaystring;

 private double regularpaydouble;
 private double grosspaydouble;
 private double overtimepaydouble;

 private int leng1=10;
 private double leng2=10;
 private arithmeticoperations arithmeticmachine;
 private Timer delayedclosing;

 //more private stuff
public arithmeticframe() {
    super("Arithmetic Frame");
    setLayout(new GridLayout(4,1));       //usage of GridLayout, 4 rows, 1 collumn.
    setTitle("Program 1"); //This title will override any title set via the super declaration.

    companynamelabel = new JLabel("<html>Quoc's TravelAir Agency<br/>Payroll System<html>");    //start of first panel
    InfoPanel = new JPanel();
    InfoPanel.setBackground(Color.red);   //set panel color to red
    InfoPanel.setPreferredSize(new Dimension(200,50));
    InfoPanel.add(companynamelabel,BorderLayout.NORTH);
    this.add(InfoPanel,BorderLayout.NORTH);                                                     //end of first panel

    employeenamelabel = new JLabel("Employee Name:");                                           //start of 2nd panel
    hoursworkedlabel = new JLabel("Hours Worked:");
    payratelabel = new JLabel("Hourly pay rate:");
    employeenametextfield = new JTextField(20);
    hoursworkedtextfield = new JTextField(20);
    payratetextfield = new JTextField(10);
    EmployeePanel = new JPanel();
    EmployeePanel.setBackground(new Color(100,140,204));
    EmployeePanel.setLayout(new FlowLayout(FlowLayout.CENTER));
    EmployeePanel.setPreferredSize(new Dimension(500,100));
    EmployeePanel.add(employeenamelabel,BorderLayout.WEST);
    EmployeePanel.add(employeenametextfield,BorderLayout.EAST);

    EmployeePanel.add(hoursworkedlabel,BorderLayout.WEST);
    EmployeePanel.add(hoursworkedtextfield,BorderLayout.EAST);

    EmployeePanel.add(payratelabel,BorderLayout.WEST);
    EmployeePanel.add(payratetextfield,BorderLayout.EAST);

    this.add(EmployeePanel);                                                                    //end of second panel

    DisplayEmployeePanel = new JPanel();                                                        //start of third panel
    displayemployeenamelabel = new JLabel("Name of Employee:");
    displayregularpaylabel = new JLabel("Regular Pay:");
    displayovertimepaylabel = new JLabel("Overtime pay:");
    displaygrosspaylabel = new JLabel("Gross Pay:");
    displayemployeenametextfield = new JTextField(20);
    displayregularpaytextfield = new JTextField(20);
    displayovertimepaytextfield = new JTextField(20);
    displaygrosspaytextfield = new JTextField(20);
    DisplayEmployeePanel.setBackground(Color.green);

    DisplayEmployeePanel.add(displayemployeenamelabel);
    DisplayEmployeePanel.add(displayemployeenametextfield);

    DisplayEmployeePanel.add(displayregularpaylabel);
    DisplayEmployeePanel.add(displayregularpaytextfield);

    DisplayEmployeePanel.add(displayovertimepaylabel);
    DisplayEmployeePanel.add(displayovertimepaytextfield);

    DisplayEmployeePanel.add(displaygrosspaylabel);
    DisplayEmployeePanel.add(displaygrosspaytextfield);

    DisplayEmployeePanel.setPreferredSize(new Dimension(100,70));
    this.add(DisplayEmployeePanel);                                                             //end of third panel

    computebutton = new JButton("Compute");                                                     //start of fourth panel
    clearbutton = new JButton("Clear");
    exitbutton = new JButton("Exit");
    ButtonLayoutPanel = new JPanel();
    ButtonLayoutPanel.add(clearbutton);
    ButtonLayoutPanel.add(computebutton);
    ButtonLayoutPanel.add(exitbutton);
    ButtonLayoutPanel.setBackground(Color.yellow);
    this.add(ButtonLayoutPanel,BorderLayout.SOUTH);                                            //end of fourth panel


    buttonhandler myhandler = new buttonhandler();
    computebutton.addActionListener(myhandler);
    exitbutton.addActionListener(myhandler);
    clearbutton.addActionListener(myhandler);
    arithmeticmachine = new arithmeticoperations();
    setLocationRelativeTo(null);  //This statement opens the UI in the center of the monitor.
    delayedclosing = new Timer(length_of_delay,myhandler);

  }//End of constructor method


private class buttonhandler implements ActionListener {
  public void actionPerformed(ActionEvent event) {
    if(event.getSource() == computebutton) {
      employeenamestring = employeenametextfield.getText();
      leng1 = employeenamestring.length();
            //System.out.println("leng = "+leng);    //Debug statement
      if(leng1 == 0) {
        employeenamestring = " ";
      }
      else{
        displayemployeenametextfield.setText(employeenamestring);
      }

      hoursworkedstring = hoursworkedtextfield.getText();
      leng2 = hoursworkedstring.length();
      payratestring = payratetextfield.getText();
      leng2 = payratestring.length();
      if(leng2 == 0) {
        hoursworkeddouble = 0; //if no input found assume user wanted zero
        payratedouble = 0; //if no input found assume user wanted zero
      }
      else{
        //hoursworkeddouble = Double.parseDouble(hoursworkedstring);
        payratedouble = Double.parseDouble(payratestring);

        regularhoursworkeddouble = 40.0;
        regularpaydouble = arithmeticoperations.regular(hoursworkedstring, payratedouble);
        regularpaystring = String.format("%f",regularpaydouble);
        displayregularpaytextfield.setText(regularpaystring);

        overtimepaydouble = arithmeticoperations.overtime(hoursworkedstring, payratedouble);
        overtimepaystring = String.format("%f",overtimepaydouble);
        displayovertimepaytextfield.setText(overtimepaystring);

        grosspaydouble = arithmeticoperations.grosspay(hoursworkedstring, payratedouble);
        grosspaystring = String.format("%f",grosspaydouble);
        displaygrosspaytextfield.setText(grosspaystring);

      }
            //System.out.println("leng = "+leng);    //Debug statement
    }
    else if(event.getSource() == clearbutton) {
      employeenamestring = " ";
      regularpaystring = " ";
      overtimepaystring = " ";
      grosspaystring = " ";
      displayemployeenametextfield.setText(employeenamestring);
      displayregularpaytextfield.setText(regularpaystring);
      displayovertimepaytextfield.setText(overtimepaystring);
      displaygrosspaytextfield.setText(grosspaystring);

    }

    else if(event.getSource() == exitbutton) {
        System.out.print("The exit button was clicked.  There are 3.5 seconds remaining.\n");
        exitbutton.setEnabled(false);
            //addbutton.setEnabled(false);
            //subtractbutton.setEnabled(false);
        delayedclosing.start();
    }
    else if(event.getSource() == delayedclosing) {
      System.exit(0);
    }
    else {
      System.out.println("Unknown error");
    }
    }//End of actionPerformed
  }//End of buttonhandler class
}//End of arithmeticframe class
