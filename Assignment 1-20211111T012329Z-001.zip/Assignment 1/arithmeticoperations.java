//****************************************************************************************************************************
//Program name: "Assignment 1".  This program calculate an employee's simple salary while displaying the pay,overtime,       *
//and gross, while using three buttons  Copyright (C) 2021 Quoc Le                                                           *
//This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License  *
//version 3 as published by the Free Software Foundation.                                                                    *
//This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied         *
//warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.     *
//A copy of the GNU General Public License v3 is available here:  <https://www.gnu.org/licenses/>.                           *
//****************************************************************************************************************************



//Author information:
  //Author: Quoc Le
  //Mail: quoctle00@csu.fullerton.edu

  //Program information:
    //Program name: Assignment 1
    //Programming language: Java
    //Files: testarithmetic.java, arithmeticframe.java, arithmeticoperations.java, run.sh
    //Date project began: 2021-January-25.
    //Date of last update: 2021-February-1.
    //Status: Finished; testing completed.
    //Purpose: This program demonstrate the design of a simple UI (user interface) where multiple panels are used
    //with different colors as well as the calculation of an employee's salary based on their hours worked and their payrate.
    //The program also has a built-in 3.5 seconds delay of closing the program after the Exit button has been clicked.
    //Nice feature: If no values or incorrect values are entered into the input boxes then zero is assumed to be the input,
    //as well as using the CLear button it will clear all data displayed, including the user input.
    //Base test system: Linux system with Bash shell and openjdk-14-jdk

//This module
  //File name: arithmeticoperations.java
  //Compile: arithmeticoperations.java
  //This module is invoked from the arithmeticframe class
  //Purpose: Handle the computation of different part of salary, such as the regular pay, the overtime pay, and the gross pay.
  //Educational purpose: Demonstrate how detailed operations unrelated to the definition of the UI can be and should be
  //off-loaded to a separate file, which is then invoked by the arithmeticframe class.  That simply means to not clutter
  //the UI file with too many junk-filled details

//Ruler:=1=========2=========3=========4=========5=========6=========7=========8=========9=========0=========1=========2=========3**


public class arithmeticoperations {//There are no private internal variables
  public static double regular(string hoursworked, double payrate) {
    double regularpay = 0.0;

    try{
      int i = Integer.parseInt(hoursworked);
    } catch (NumberFormatException e) {
      double d = Double.parseDouble(hoursworked);
    }

  /*  if(hoursworked instanceof Integer) {
      return 0;
    } */
    if(hoursworked <= 40.0 && hoursworked > 0.0)
    {
      regularpay = hoursworked * payrate;
    }
    //has to clear all of these conditions to execute
    else if(hoursworked > 40.0 && hoursworked <= 168.0)
    {
      regularpay = 40.0 * payrate;
    }
    else
    {
      regularpay = 0.0;
    }

    return regularpay;
  }
  public static double overtime(double hoursworked, double payrate) {
    double overtimepay = 0.0;
    if(hoursworked > 40.0 && hoursworked <= 168.0){
      hoursworked = hoursworked - 40.0;
      if(hoursworked > 0.0){
        overtimepay = hoursworked * payrate * 1.5;
        return overtimepay;
      }
      else{
        overtimepay = 0.0;
      }
    }
    return overtimepay;
  }

  public static double grosspay(double hoursworked, double payrate) {
    return overtime(hoursworked, payrate) + regular(hoursworked, payrate);
  }
}//End arithmeticoperations class


//Footnote: Admittedly, adding and subtracting are rather trivial operations.  They don't really need to be programmed in
//a separate file.  The two methods are placed in this class called arithmeticoperations simply to demonstrate how to
//remove detailed algorithms out of the class defining the user interface.
