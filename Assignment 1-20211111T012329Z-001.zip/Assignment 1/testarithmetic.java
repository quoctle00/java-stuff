//****************************************************************************************************************************
//Program name: "Assignment 1".  This program calculate an employee's simple salary while displaying the pay,overtime,       *
//and gross, while using three buttons  Copyright (C) 2021 Quoc Le                                                           *
//This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License  *
//version 3 as published by the Free Software Foundation.                                                                    *
//This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied         *
//warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.     *
//A copy of the GNU General Public License v3 is available here:  <https://www.gnu.org/licenses/>.                           *
//****************************************************************************************************************************

//Ruler:=1=========2=========3=========4=========5=========6=========7=========8=========9=========0=========1=========2=========3**

//Author information:
  //Author: Quoc Le
  //Mail: quoctle00@csu.fullerton.edu

  //Program information:
    //Program name: Assignment 1
    //Programming language: Java
    //Files: testarithmetic.java, arithmeticframe.java, arithmeticoperations.java, run.sh
    //Date project began: 2021-January-25.
    //Date of last update: 2021-February-1.
    //Status: Finished; testing completed.
    //Purpose: This program demonstrate the design of a simple UI (user interface) where multiple panels are used
    //with different colors as well as the calculation of an employee's salary based on their hours worked and their payrate.
    //The program also has a built-in 3.5 seconds delay of closing the program after the Exit button has been clicked.
    //Nice feature: If no values or incorrect values are entered into the input boxes then zero is assumed to be the input,
    //as well as using the CLear button it will clear all data displayed, including the user input.
    //Base test system: Linux system with Bash shell and openjdk-14-jdk

//This module
  //File name: testarithmetic.java
  //Compile : javac testarithmetic.java
  //This is the top level module.  This module activates the user interface.

import javax.swing.JFrame;
public class testarithmetic
{public static void main(String[] args)
    {arithmeticframe myframe = new arithmeticframe();
     myframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
     myframe.setSize(700,300);
     myframe.setVisible(true);
    }//End of main
}//End of class testarithmetic
