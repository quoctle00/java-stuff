import javax.swing.JFrame;
public class driver
{public static void main(String[] args)
    {uiframe myframe = new uiframe();
     myframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
     myframe.setSize(700,500);  //(width, height)
     myframe.setVisible(true);
    }//End of main
}//End of class testarithmetic
