import java.awt.FlowLayout;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.Dimension;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JTable;
import java.awt.Color;
import javax.swing.Timer;

public class uiframe extends JFrame
{
  private final int length_of_delay = 1500;  //Time is measured in milliseconds

 private JFrame frame;
 private JPanel InfoPanel;                  //1st panel
 private JPanel InputPanel;              //2nd panel
 private JPanel DisplayPanel;       //3rd panel
 private JPanel ButtonLayoutPanel;          //4th panel

 private JLabel companynamelabel;

 private JButton exitbutton;
 private JButton computebutton;
 private JButton clearbutton;

 private JLabel input1label;
 private JLabel input2label;
 private JTextField input1textfield;
 private JTextField input2textfield;

 private JLabel displayHypotenuselabel;
 private JLabel displayArealabel;
 private JTextField displayHypotenusetextfield;
 private JTextField displayAreatextfield;

 private String input1string;
 private String input2string;
 private String Hypotenusestring;
 private String Areastring;

 private double input1double;
 private double input2double;
 private double Hypotenusedouble;
 private double Areadouble;

 private String regularpaystring;
 private String overtimepaystring;
 private String grosspaystring;

 private double regularpaydouble;
 private double grosspaydouble;
 private double overtimepaydouble;

 private int leng1=10;
 private int leng2=10;
 private computation computationmachine;
 private Timer delayedclosing;

 //more private stuff
 public uiframe() {
    super("TriangleCompute Frame");
    setLayout(new GridLayout(3,1));       //usage of GridLayout, 3 rows, 1 collumn.
    setTitle("Test 1"); //This title will override any title set via the super declaration.

    companynamelabel = new JLabel("<html>Quoc's Triangle computation<br/>programmed by Quoc<br/> All triangles are right<html>");    //start of first panel
    InfoPanel = new JPanel();
    InfoPanel.setBackground(Color.green);
    InfoPanel.setPreferredSize(new Dimension(200,50));
    InfoPanel.add(companynamelabel,BorderLayout.NORTH);
    this.add(InfoPanel,BorderLayout.NORTH);

    InputPanel = new JPanel();
    InputPanel.setLayout(new GridLayout(4,2));
    input1label = new JLabel("Input side 1:");
    input2label = new JLabel("Input side 2:");
    displayHypotenuselabel = new JLabel("Hypotenuse is:");
    displayArealabel = new JLabel("Area is:");

    input1textfield = new JTextField(20);
    input2textfield = new JTextField(20);
    displayHypotenusetextfield = new JTextField(20);
    displayAreatextfield = new JTextField(20);

    InputPanel.add(input1label);
    InputPanel.add(input1textfield);

    InputPanel.add(input2label);
    InputPanel.add(input2textfield);

    InputPanel.add(displayHypotenuselabel);
    InputPanel.add(displayHypotenusetextfield);

    InputPanel.add(displayArealabel);
    InputPanel.add(displayAreatextfield);

    InputPanel.setBackground(Color.blue);
    this.add(InputPanel,BorderLayout.CENTER);

    ButtonLayoutPanel = new JPanel();
    computebutton = new JButton("Compute");
    clearbutton = new JButton("Clear");
    exitbutton = new JButton("Exit");
    ButtonLayoutPanel.add(computebutton);
    ButtonLayoutPanel.add(clearbutton);
    ButtonLayoutPanel.add(exitbutton);
    ButtonLayoutPanel.setBackground(Color.magenta);
    this.add(ButtonLayoutPanel,BorderLayout.SOUTH);

    buttonhandler myhandler = new buttonhandler();
    computebutton.addActionListener(myhandler);
    exitbutton.addActionListener(myhandler);
    clearbutton.addActionListener(myhandler);
    computationmachine = new computation();
    setLocationRelativeTo(null);  //This statement opens the UI in the center of the monitor.
    delayedclosing = new Timer(length_of_delay,myhandler);

  } // end of constructor

  private class buttonhandler implements ActionListener {
    public void actionPerformed(ActionEvent event) {
      if(event.getSource() == computebutton) {
        input1string = input1textfield.getText();
        leng1 = input1string.length();
            //System.out.println("leng = "+leng);    //Debug statement
            if(leng1 == 0) {
              input1string = " ";
            }
            else{
              input1textfield.setText(input1string);
            }

          input2string = input2textfield.getText();
          leng2 = input2string.length();
            if(leng2 == 0) {
              Hypotenusedouble = 0; //if no input found assume user wanted zero
              Areadouble = 0; //if no input found assume user wanted zero
            }
            else{
              input1double = Double.parseDouble(input1string);
              input2double = Double.parseDouble(input2string);

              Hypotenusedouble = computation.hypotenusecompute(input1double, input2double);
              Hypotenusestring = String.format("%f",Hypotenusedouble);
              displayHypotenusetextfield.setText(Hypotenusestring);

              Areadouble = computation.areacompute(input1double, input2double);
              Areastring = String.format("%f",Areadouble);
              displayAreatextfield.setText(Areastring);
            }
      }
      else if(event.getSource() == clearbutton) {
        input1string = " ";
        input2string = " ";
        Hypotenusestring = " ";
        Areastring = " ";
        input1textfield.setText(input1string);
        input2textfield.setText(input2string);
        displayHypotenusetextfield.setText(Hypotenusestring);
        displayAreatextfield.setText(Areastring);
      }

      else if(event.getSource() == exitbutton) {
        exitbutton.setEnabled(false);
        System.exit(0);
      }
      else {
        System.out.println("Unknown error");
      }

    }
  }
}
