#!/bin/bash

#Program name: Basic Arithmetic 1.0
#Author: Floyd Holliday
#Email: holliday@fullerton.edu
#File name:  run.sh
#Preconditions:
#   1.  All source files are in one directory
#   2.  This file, run.sh, is in that same directory
#   3.  The shell is currently active in that same directory
#How to execute: Enter "sh run.sh" without the quotes.

echo Remove old byte-code files if any exist
rm *.class

echo View list of source files
ls -l *.java

echo Compile computation.java
javac computation.java

echo Compile uiframe.java
javac uiframe.java

echo Compile driver.java
javac driver.java

echo Execute the Triangle program
java driver

echo End of execution.  Have a nice day.
