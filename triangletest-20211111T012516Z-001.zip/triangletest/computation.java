import java.lang.Math;

public class computation {//There are no private internal variables
  public static double hypotenusecompute(double a, double b) {
    double c = 0.0;
    if(a < 0 || b < 0) {
      return 0;
    }
    else {
      double a2 = a * a;
      double b2 = b * b;
      double c2 = a2 + b2;
      c = Math.sqrt(c2);
      //return c;
    }
    return c;
  }
  public static double areacompute(double side1, double side2) {
    double area = 0.0;

    if(side1 < 0 || side2 < 0) {
      return 0;
    }
    else {
      double product = side1 * side2;
      area = product / 2;
      //return area;
    }

    return area;
  }


}//End arithmeticoperations class
