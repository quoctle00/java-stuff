//****************************************************************************************************************************
//Program name: "Quoc's Ball bounce.".This program display a circle bouncing off of the edge of the screen                   *
//Copyright (C) 2021 Quoc Le                                                                                                 *
//This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License  *
//version 3 as published by the Free Software Foundation.                                                                    *
//This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied         *
//warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.     *
//A copy of the GNU General Public License v3 is available here:  <https://www.gnu.org/licenses/>.                           *
//****************************************************************************************************************************



//Author information:
  //Author: Quoc Le
  //Mail: quoctle00@csu.fullerton.edu

  //Program information:
    //Program name: Quoc's Bouncing Ball
    //Programming language: Java
    //Files: Ballbounce.java, ballbouncepanel.java, deltaoperation.java, maindriver.java run.sh
    //Date project began: 2021-March-3.
    //Date of last update: 2021-March-19.
    //Status: Finished; testing completed.
    //Purpose: This program will animate a circle moving in a direction bouncing off of a wall, moving circle will leave a trail of paint behind,
    //changing color rapidly as it is moving.
    //Nice feature: this program has a start and pause button, user can also change the speed of the ball moving, albeit only using
    //whole number, no decimal or invalid input such as letters or any kind of symbols.
    //Base test system: Linux system with Bash shell and openjdk-14-jdk

//This module
  //File name: bouncepanel.java
  //Compile: bouncepanel.java
  //This module is invoked from the Ballbounce class
  //Purpose: Act as the main panel where the animation and drawing will be done.
  //Educational purpose: Demonstrate how detailed operations unrelated to the definition of the UI can be and should be
  //off-loaded to a separate file, which is then invoked by the frame class.  That simply means to not clutter
  //the UI file with too many junk-filled details

//Ruler:=1=========2=========3=========4=========5=========6=========7=========8=========9=========0=========1=========2=========3**

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Dimension;
import javax.swing.JPanel;
import java.awt.BasicStroke;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.Timer;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


public class bouncepanel extends JPanel implements ActionListener{

  int panel_width = 1920;
  int panel_height = 930;
  int ticking_clock;
  int counter = 0;
  int x = 960;
  int y = 465;
  int x_size = 25;
  int y_size = 25;
  //int delta = 0;
  double velocityXdouble = 0;
  double velocityYdouble = 0;
  int velocityX = 0;
  int velocityY = 0;
  Timer timer = new Timer(ticking_clock,this);
  int randomRint = 0;
  int randomGint = 0;
  int randomBint = 255;
  int r = 50;
  int g = 50;
  int b = 50;
  double randomR = 0;
  double randomG = 0;
  double randomB = 0;
  int min = 0;
  int max = 255;
  double newTicRate = 0;
  double newDirection = 0;

  public Integer getMyValue(int tick){
    ticking_clock = tick;
    if(tick <= 0) {
      return 0;
    }
    else {
      timer = new Timer(tick,this);
    }
    return ticking_clock;
  }

  public Double getTicRate(double ticRate) {
    newTicRate = ticRate;
    if(ticRate <= 0) {
      newTicRate = 0;
      return newTicRate;
    }
    else {
      newTicRate = ticRate;
    }
    return newTicRate;
  }

  public Double getDirection(double direction) {
    newDirection = direction;
    return newDirection;
  }

  public void bouncepanelStart(){
    timer.start();
    this.setPreferredSize(new Dimension(panel_width,panel_width));
    this.setBackground(new Color(50,50,255));  //RGB
  }

  public void bouncepanelPause(){
    timer.stop();
  }
  public Integer getBallcoordX(int x_coord) {
    x = x_coord;
    if(x_coord <= 0) {
      return 0;
    }
    else {
      x = x_coord;
    }
    return x;
  }
  public Integer getBallcoordY(int y_coord) {
    y = y_coord;
    if(y_coord <= 0) {
      return 0;
    }
    else {
      y = y_coord;
    }
    return y;
  }

  public void paint(Graphics g) {
    super.paint(g);
    this.setBackground(new Color(50,50,50));

    Graphics2D g2D = (Graphics2D) g;


    //g2D.setColor(Color.blue);
    g2D.setColor(new Color(5,5,5));
    g2D.fillOval(x, y, x_size, y_size);

    //repaint();
  }

  public Integer getDeltaX(int main_deltax) {
    velocityX = main_deltax*2;
    return velocityX;
  }
  public Integer getDeltaY(int main_deltay) {
    velocityY = main_deltay*2;
    return velocityY;
  }

  public void actionPerformed(ActionEvent e) {
  /*  randomR = Math.random() * (max - min + 1) + min;
    randomRint = (int)Math.round(randomR);
    randomG = Math.random() * (max - min + 1) + min;
    randomGint = (int)Math.round(randomG);
    randomB = Math.random() * (max - min + 1) + min;
    randomBint = (int)Math.round(randomB);
    r = r - 25;
    g = g + 200;
    b = b + 200;
*/
    if(x >= panel_width - x_size || x<=0) {
      velocityX = velocityX * -1;
    }
    x = x + velocityX;

    if(y >= panel_height - y_size || y<=0) {
      velocityY = velocityY * -1;
    }
    y = y + velocityY;
    repaint();

    //Ballbounce.ballX(x);
    //Ballbounce.ballY(y);
  }
}
