//****************************************************************************************************************************
//Program name: "Quoc's Orbital planets" This program will simulate Earth and Mars orbiting the Sun                          *
//Copyright (C) 2021 Quoc Le                                                                                                 *
//This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License  *
//version 3 as published by the Free Software Foundation.                                                                    *
//This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied         *
//warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.     *
//A copy of the GNU General Public License v3 is available here:  <https://www.gnu.org/licenses/>.                           *
//****************************************************************************************************************************



//Author information:
  //Author: Quoc Le
  //Mail: quoctle00@csu.fullerton.edu

  //Program information:
    //Program name: Quoc's Orbital PLanets
    //Programming language: Java
    //Files: Ballbounce.java, ballbouncepanel.java, deltaoperation.java, maindriver.java run.sh
    //Date project began: 2021-May-19.
    //Date of last update: 2021-May-19.
    //Status: Finished; testing completed.
    //Purpose: This program will animate a green and red circle orbiting a yellow circle
    //Base test system: Linux system with Bash shell and openjdk-14-jdk

//This module
  //File name: bouncepanel.java
  //Compile: Ballbounce.java
  //This module is invoked from the maindriver class
  //Purpose: Act as the main frame of the program
  //Educational purpose: Demonstrate how detailed operations unrelated to the definition of the UI can be and should be
  //off-loaded to a separate file, which is then invoked by the frame class.  That simply means to not clutter
  //the UI file with too many junk-filled details

//Ruler:=1=========2=========3=========4=========5=========6=========7=========8=========9=========0=========1=========2=========3**


import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Dimension;
import javax.swing.JPanel;
import java.awt.BasicStroke;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.Timer;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


public class bouncepanel extends JPanel implements ActionListener{

  int panel_width = 1920;  //use 1920 for finish product, use 900 for testing
  int panel_height = 930;  //use 930 for finish product, use 300 for testing
  int ticking_clock;
  int counter = 0;
  int x = 800; //use 960 for finish product, use 800 for testing
  int y = 250; //use 465 for finish product, use 250 for testing
  int sunX = 600;
  int sunY = 250;
  int marsX = 1000;
  int marsY = 250;
  int x_size = 25;
  int y_size = 25;
  double velocityXdouble = 0;
  double velocityYdouble = 0;
  int velocityX = 0;
  int velocityY = 0;
  int mars_DtX = 0;
  int mars_DtY = 0;
  Timer timer = new Timer(1,this);


  double newTicRate = 0;
  double newDirection = 0;

  double R = 200;
  double marsR = 400;
  double delta_t = 0;
  double theta = 0;
  double marsTheta = 0;

  public Ballbounce Frame;


  public Integer getMyValue(int tick){
    ticking_clock = tick;
    if(tick <= 0) {
      return 0;
    }
    else {
      timer = new Timer(tick,this);
    }
    return ticking_clock;
  }

  public Double getTicRate(double ticRate) {
    newTicRate = ticRate;
    if(ticRate <= 0) {
      newTicRate = 0;
      return newTicRate;
    }
    else {
      newTicRate = ticRate;
    }
    return newTicRate;
  }

  public Double getDirection(double direction) {
    newDirection = direction;
    return newDirection;
  }

  public void bouncepanelStart(){
    timer.start();
    //this.setPreferredSize(new Dimension(panel_width,panel_width));
    //this.setBackground(new Color(50,50,255));  //RGB
  }

  public void bouncepanelPause(){
    timer.stop();
  }


  public void paint(Graphics g) {
    super.paint(g);
    this.setBackground(new Color(5,5,5));

    Graphics2D g2D = (Graphics2D) g;
    Graphics2D sun2D = (Graphics2D) g;
    Graphics2D mars2D = (Graphics2D) g;

    g2D.setColor(new Color(1,150,50));
    g2D.fillOval(x, y, x_size, y_size);
    sun2D.setColor(Color.yellow);
    sun2D.fillOval(sunX,sunY,40,40);
    mars2D.setColor(Color.red);
    mars2D.fillOval(marsX, marsY,x_size, y_size);
  }


  public void resetLocation() {
    x = 800;
    y = 250;
  }

  public Double getDeltaT(double new_theta) {
    delta_t = new_theta;
    return delta_t;
  }


  public void actionPerformed(ActionEvent e) {
    timer.start();
    theta = theta + delta_t;
    marsTheta = theta / 2;

    velocityX = (int)Math.round(deltaoperation.Rcos(theta,R));
    velocityY = (int)Math.round(deltaoperation.Rsin(theta,R));
    mars_DtX = (int)Math.round(deltaoperation.Rcos(marsTheta,marsR));
    mars_DtY = (int)Math.round(deltaoperation.Rsin(marsTheta,marsR));

    x = sunX + velocityX;
    y = sunY + velocityY;

    marsX = sunX + mars_DtX;
    marsY = sunY + mars_DtY;

    repaint();


  }//end of repaint
}
