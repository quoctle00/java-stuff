//****************************************************************************************************************************
//Program name: "Quoc's Diamond drawing.".This program calculate an employee's simple salary while displaying the pay,overtime,       *
//and gross, while using three buttons  Copyright (C) 2021 Quoc Le                                                           *
//This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License  *
//version 3 as published by the Free Software Foundation.                                                                    *
//This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied         *
//warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.     *
//A copy of the GNU General Public License v3 is available here:  <https://www.gnu.org/licenses/>.                           *
//****************************************************************************************************************************



//Author information:
  //Author: Quoc Le
  //Mail: quoctle00@csu.fullerton.edu

  //Program information:
    //Program name: Quoc's Diamond drawing
    //Programming language: Java
    //Files: DiamondAnimationframe.java, diamondpaneldrawing.java, deltaoperation.java, testarithmetic.java run.sh
    //Date project began: 2021-February-19.
    //Date of last update: 2021-March-1.
    //Status: Finished; testing completed.
    //Purpose: This program will animate a circle moving in a diamond, moving circle will leave a trail of paint behind.
    //Nice feature: this program has a start and pause button, user can also change the speed of the ball moving, albeit only using
    //whole number, no decimal or invalid input such as letters or any kind of symbols.
    //WARNING: This program has a feature that rapidly change the color of the circle as it moves, if the user has epilepsy please
    //refrain from using it. Contact the author if the user wish to see a safer version.
    //Base test system: Linux system with Bash shell and openjdk-14-jdk

//This module
  //File name: testarithmetic.java
  //Compile: testarithmetic.java
  //This module is invoked from the diamondpaneldrawing class
  //Purpose: Act as the driver of the program
  //Educational purpose: Demonstrate how detailed operations unrelated to the definition of the UI can be and should be
  //off-loaded to a separate file, which is then invoked by the frame class.  That simply means to not clutter
  //the UI file with too many junk-filled details

//Ruler:=1=========2=========3=========4=========5=========6=========7=========8=========9=========0=========1=========2=========3**

import javax.swing.JFrame;
public class testarithmetic
{public static void main(String[] args)
    {
      DiamondAnimationframe myframe = new DiamondAnimationframe();
     myframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
     myframe.setSize(1920,1080); //techincally(600,600) since the top and bottom panel took 100 of height. (width, height)
     myframe.setVisible(true);
    }//End of main
}//End of class testarithmetic
