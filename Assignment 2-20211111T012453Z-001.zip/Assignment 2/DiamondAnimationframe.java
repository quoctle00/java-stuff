//****************************************************************************************************************************
//Program name: "Quoc's Diamond drawing.".This program calculate an employee's simple salary while displaying the pay,overtime,       *
//and gross, while using three buttons  Copyright (C) 2021 Quoc Le                                                           *
//This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License  *
//version 3 as published by the Free Software Foundation.                                                                    *
//This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied         *
//warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.     *
//A copy of the GNU General Public License v3 is available here:  <https://www.gnu.org/licenses/>.                           *
//****************************************************************************************************************************



//Author information:
  //Author: Quoc Le
  //Mail: quoctle00@csu.fullerton.edu

  //Program information:
    //Program name: Quoc's Diamond drawing
    //Programming language: Java
    //Files: DiamondAnimationframe.java, diamondpaneldrawing.java, deltaoperation.java, testarithmetic.java run.sh
    //Date project began: 2021-February-19.
    //Date of last update: 2021-March-1.
    //Status: Finished; testing completed.
    //Purpose: This program will animate a circle moving in a diamond, moving circle will leave a trail of paint behind.
    //Nice feature: this program has a start and pause button, user can also change the speed of the ball moving, albeit only using
    //whole number, no decimal or invalid input such as letters or any kind of symbols.
    //WARNING: This program has a feature that rapidly change the color of the circle as it moves, if the user has epilepsy please
    //refrain from using it. Contact the author if the user wish to see a safer version.
    //Base test system: Linux system with Bash shell and openjdk-14-jdk

//This module
  //File name: DiamondAnimationframe.java
  //Compile: DiamondAnimationframe.java
  //This module is invoked from the diamondpaneldrawing class
  //Purpose: Act as the frame that holds all panels
  //Educational purpose: Demonstrate how detailed operations unrelated to the definition of the UI can be and should be
  //off-loaded to a separate file, which is then invoked by the frame class.  That simply means to not clutter
  //the UI file with too many junk-filled details

//Ruler:=1=========2=========3=========4=========5=========6=========7=========8=========9=========0=========1=========2=========3**

import java.awt.FlowLayout;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.Dimension;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JTable;
import java.awt.Color;
import javax.swing.Timer;
import java.awt.Graphics2D;

public class DiamondAnimationframe extends JFrame {
  private JFrame frame;
  private JPanel NamePanel;
  //private JPanel DiamondPanel;
  private JPanel ButtonPanel;

  private JLabel diamondnamelabel;
  private JLabel speedlabel;
  private JLabel instructionlabel;
  private JTextField speedtextfield;
  private String speedstring;
  public int speedint;
  public double speeddouble;
  private JButton startbutton;
  private JButton exitbutton;

  private diamondpaneldrawing DiamondPanel;
  Timer clock;
  public int clock_tick;


  public DiamondAnimationframe() {
    //Timer clock = new Timer(10,this);

    super("Baseball diamond");
    setLayout(new BorderLayout());
    setTitle("Program 2");

    diamondnamelabel = new JLabel("<html>Diamond animation<br/>By Quoc Le<html>");    //start of first panel
    NamePanel = new JPanel();
    NamePanel.setBackground(Color.yellow);   //set panel color to red
    NamePanel.setPreferredSize(new Dimension(50,50));       // (Length, height)
    NamePanel.add(diamondnamelabel,BorderLayout.NORTH);
    this.add(NamePanel,BorderLayout.NORTH);


    DiamondPanel = new diamondpaneldrawing();
    //DiamondPanel.clock.stop();
    /*DiamondPanel = new JPanel();
    //DiamondPanel.setPreferredSize(new Dimension(700,400));
    this.add(DiamondPanel,BorderLayout.CENTER);
    */
    DiamondPanel.setBackground(Color.green);   //set panel color to green
    this.add(DiamondPanel,BorderLayout.CENTER);
    this.pack();


    ButtonPanel = new JPanel();
    ButtonPanel.setBackground(Color.magenta);
    ButtonPanel.setPreferredSize(new Dimension(100,50));
    //ButtonPanel.setLayout(new GridLayout(1,4));
    startbutton = new JButton("Start");
    startbutton.setForeground(Color.white);
    startbutton.setBackground(Color.blue);
    speedlabel = new JLabel("Speed:");
    instructionlabel = new JLabel("The bigger the number, the slower it goes. Input whole number above 0 only");
    speedtextfield = new JTextField(20);
    exitbutton = new JButton("Exit");
    exitbutton.setForeground(Color.white);
    exitbutton.setBackground(Color.red);
    ButtonPanel.add(startbutton);
    ButtonPanel.add(speedlabel);
    ButtonPanel.add(speedtextfield);
    ButtonPanel.add(instructionlabel);
    ButtonPanel.add(exitbutton);
    this.add(ButtonPanel,BorderLayout.SOUTH);


    buttonhandler myhandler = new buttonhandler();
    startbutton.addActionListener(myhandler);
    exitbutton.addActionListener(myhandler);
    //arithmeticmachine = new arithmeticoperations();
    setLocationRelativeTo(null);  //This statement opens the UI in the center of the monitor.


  }//End of Constructor

  public class buttonhandler implements ActionListener {
    Timer clock = new Timer(clock_tick,DiamondPanel);
    boolean labelisstart = true;
    public void actionPerformed(ActionEvent event) {
      if(event.getSource() == startbutton) {
        if(labelisstart){
          speedstring = speedtextfield.getText();
          speeddouble = Double.parseDouble(speedstring);
          speedint = (int)Math.round(speeddouble);
          clock_tick = speedint * 10;
          if(clock_tick <= 0) {
            clock.stop();
            DiamondPanel.diamondpaneldrawingpause();
          }
          else if(clock_tick > 0) {
            DiamondPanel.getMyValue(clock_tick);
            DiamondPanel.diamondpaneldrawing();
            startbutton.setText("Pause");
          }
          else {
            clock.stop();
            DiamondPanel.diamondpaneldrawingpause();
            System.out.println("Invalid Input, please enter a number that contains no letters.\n");
          }
        }
        else {
          //clock.stop();
          DiamondPanel.diamondpaneldrawingpause();
          startbutton.setText("Start");
        }
        labelisstart = !labelisstart;

      }



      if(event.getSource() == exitbutton) {
        System.out.print("The exit button was clicked.  There are 3.5 seconds remaining.\n");
        exitbutton.setEnabled(false);
            //addbutton.setEnabled(false);
            //subtractbutton.setEnabled(false);
        System.exit(0);
      }
    }

  }
}
