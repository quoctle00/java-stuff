//****************************************************************************************************************************
//Program name: "Quoc's Diamond drawing.".This program calculate an employee's simple salary while displaying the pay,overtime,       *
//and gross, while using three buttons  Copyright (C) 2021 Quoc Le                                                           *
//This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License  *
//version 3 as published by the Free Software Foundation.                                                                    *
//This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied         *
//warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.     *
//A copy of the GNU General Public License v3 is available here:  <https://www.gnu.org/licenses/>.                           *
//****************************************************************************************************************************



//Author information:
  //Author: Quoc Le
  //Mail: quoctle00@csu.fullerton.edu

  //Program information:
    //Program name: Quoc's Diamond drawing
    //Programming language: Java
    //Files: DiamondAnimationframe.java, diamondpaneldrawing.java, deltaoperation.java, testarithmetic.java run.sh
    //Date project began: 2021-February-19.
    //Date of last update: 2021-March-1.
    //Status: Finished; testing completed.
    //Purpose: This program will animate a circle moving in a diamond, moving circle will leave a trail of paint behind.
    //Nice feature: this program has a start and pause button, user can also change the speed of the ball moving, albeit only using
    //whole number, no decimal or invalid input such as letters or any kind of symbols.
    //WARNING: This program has a feature that rapidly change the color of the circle as it moves, if the user has epilepsy please
    //refrain from using it. Contact the author if the user wish to see a safer version.
    //Base test system: Linux system with Bash shell and openjdk-14-jdk

//This module
  //File name: diamondpaneldrawing.java
  //Compile: diamondpaneldrawing.java
  //This module is invoked from the DiamondAnimationframe class
  //Purpose: Act as the main panel where the animation and drawing will be done.
  //Educational purpose: Demonstrate how detailed operations unrelated to the definition of the UI can be and should be
  //off-loaded to a separate file, which is then invoked by the frame class.  That simply means to not clutter
  //the UI file with too many junk-filled details

//Ruler:=1=========2=========3=========4=========5=========6=========7=========8=========9=========0=========1=========2=========3**

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Dimension;
import javax.swing.JPanel;
import java.awt.BasicStroke;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.Timer;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


public class diamondpaneldrawing extends JPanel implements ActionListener{

  int tick;
  int counter = 0;
  int x = 290;
  int y = 40;
  int delta = 1;
  int velocityX = delta;
  int velocityY = delta;
  Timer timer = new Timer(tick,this);
  double randomR = 0;
  double randomG = 0;
  double randomB = 0;
  int randomRint = 10;
  int randomGint = 10;
  int randomBint = 255;
  int min = 0;
  int max = 255;

  public Integer getMyValue(int tick){
    tick = tick;
    if(tick <= 0) {
      return 0;
    }
    else {
      timer = new Timer(tick,this);
    }
    return tick;
  }

  public void diamondpaneldrawing(){

    timer.start();
    this.setPreferredSize(new Dimension(600,600));
    this.setBackground(new Color(50,50,255));  //RGB
  }

  public void diamondpaneldrawingpause(){
    timer.stop();
  }

  public void paint(Graphics g) {

    Graphics2D g2D = (Graphics2D) g;
    g2D.setStroke(new BasicStroke(3));
    //(x1, y1, x2, y2)
    g2D.drawLine(300,50,550,300); //UpperRightLine
    g2D.drawLine(300,550,550,300);  //LowerRightLine
    g2D.drawLine(300,550,50,300);  //LowerLeftLine
    g2D.drawLine(300,50,50,300);  //UpperLeftLine

    g2D.setColor(new Color(randomRint,randomGint,randomBint));
    //repaint();
    g2D.fillOval(x, y, 25, 25);
    repaint();

  }

  public void actionPerformed(ActionEvent e) {
    randomR = Math.random() * (max - min + 1) + min;
    randomRint = (int)Math.round(randomR);
    randomG = Math.random() * (max - min + 1) + min;
    randomGint = (int)Math.round(randomG);
    randomB = Math.random() * (max - min + 1) + min;
    randomBint = (int)Math.round(randomB);

    if(x == 540 && y == 290) {
      velocityX = velocityX * -1;
      counter++;
    }
    if(x == 290 && y == 540) {
      velocityY = velocityY * -1;
      counter++;
    }
    if(x == 40 && y == 290) {
      velocityX = velocityX * -1;
      counter++;
    }
    if(x == 290 && y == 40){
      counter++;
      velocityX = delta;
      velocityY = delta;
    }
    if(counter >= 5) {
      timer.stop();
      counter = 1;
    }
    x = deltaoperation.deltaX(x, velocityX);
    y = deltaoperation.deltaY(y, velocityY);
    repaint();

  }
}
