import java.awt.FlowLayout;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.Dimension;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JTable;
import java.awt.Color;
import javax.swing.Timer;

public class DiamondAnimationframe extends JFrame {
  private JFrame frame;
  private JPanel NamePanel;
  private JPanel DiamondPanel;
  private JPanel ButtonPanel;

  private JLabel diamondnamelabel;
  private JLabel speedlabel;
  private JTextField speedtextfield;
  private double speeddouble;
  private JButton Startbutton;
  private JButton Quitbutton;

  public DiamondAnimationframe() {
    

    super("Baseball diamond");
    setLayout(new GridLayout(3,1));
    setTitle("Program 2");

    diamondnamelabel = new JLabel("<html>Diamond animation<br/>By Quoc Le<html>");    //start of first panel
    DiamondPanel = new JPanel();
    InfoPanel.setBackground(Color.yellow);   //set panel color to red
    InfoPanel.setPreferredSize(new Dimension(200,50));
    InfoPanel.add(diamondnamelabel,BorderLayout.NORTH);
    this.add(DiamondPanel,BorderLayout.NORTH);


  }
}
